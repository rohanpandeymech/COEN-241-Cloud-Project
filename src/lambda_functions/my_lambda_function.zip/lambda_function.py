import json
import requests
from bs4 import BeautifulSoup
import boto3

# Extract article text from URL
def extract_text(url):
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.content, 'html.parser')
        article_text = ' '.join(p.text for p in soup.find_all('p'))
        return article_text
    except Exception as e:
        print(f"Error extracting text from URL {url}: {e}")
        return None

# Summarize the article text (implement this function)
def summarize(text):
    # Use a third-party library or service to summarize the text
    # or implement your own summarization algorithm
    summary = "This is a placeholder summary."
    return summary

# Store the summary and URL in DynamoDB
def store_summary(url, summary):
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('your-table-name')
        table.put_item(
            Item={
                'url': url,
                'summary': summary
            }
        )
    except Exception as e:
        print(f"Error storing summary in DynamoDB for URL {url}: {e}")

# Lambda handler function
def lambda_handler(event, context):
    # Get the URL from the POST request data
    url = json.loads(event['body'])['url']

    # Extract the article text
    article_text = extract_text(url)
    #if article_text is None:
        #return {
            #'statusCode': 500,
            #'body': json.dumps({'error': 'Failed to extract article text'})
        #}

    # Summarize the article text
    #summary = summarize(article_text)

    # Store the summary and URL in DynamoDB
    #store_summary(url, summary)

    # Return the summary as the response
    return {
        'statusCode': 200,
        'body': json.dumps({'summary': article_text})
    }
